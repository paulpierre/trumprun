﻿////////////////////////////////////////////////////////////////////////////////
//  
// @module Android Native Plugin for Unity3D 
// @author Osipov Stanislav (Stan's Assets) 
// @support stans.assets@gmail.com 
//
////////////////////////////////////////////////////////////////////////////////

using UnityEngine;
using System.Collections;



namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Google Ad")]
	public class AN_InterstitialEvents : FsmStateAction {

		 
		public FsmEvent OnLoadedEvent;
		public FsmEvent OnFailedToLoadEvent;

		public FsmEvent OnOpenEvent;
		public FsmEvent OnCloseEvent;
		public FsmEvent OnLeftApplicationEvent;

		
		public override void OnEnter() {

			AndroidAdMobController.Instance.OnInterstitialLoaded += OnLoaded;
			AndroidAdMobController.Instance.OnInterstitialFailedLoading += OnFailedToLoad;

			AndroidAdMobController.Instance.OnInterstitialOpened += OnOpen;
			AndroidAdMobController.Instance.OnInterstitialClosed += OnClose;
			AndroidAdMobController.Instance.OnInterstitialLeftApplication += OnLeftApplication;

		}


		private void OnLoaded() {
			Fsm.Event(OnLoadedEvent);
		}

		private void OnFailedToLoad() {
			Fsm.Event(OnFailedToLoadEvent);
		}


		private void OnOpen() {
			Fsm.Event(OnOpenEvent);
		}

		private void OnClose() {
			Fsm.Event(OnCloseEvent);
		}

		private void OnLeftApplication() {
			Fsm.Event(OnLeftApplicationEvent);
		}


		void OnDestroy() {
			AndroidAdMobController.Instance.OnInterstitialLoaded -= OnLoaded;
			AndroidAdMobController.Instance.OnInterstitialFailedLoading -= OnFailedToLoad;
			
			AndroidAdMobController.Instance.OnInterstitialOpened -= OnOpen;
			AndroidAdMobController.Instance.OnInterstitialClosed -= OnClose;
			AndroidAdMobController.Instance.OnInterstitialLeftApplication -= OnLeftApplication;
		}
		

		
	}
}
