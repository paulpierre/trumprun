﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("Android Native - Billing")]
	public class AN_RetriveProductInfo : FsmStateAction {

		public FsmString ProductSKU  = "";

		public FsmFloat price;	
		public FsmString title;
		public FsmString description;
		public FsmInt priceAmountMicros;
		public FsmString priceCurrencyCode;

		public FsmEvent successEvent;
		public FsmEvent failEvent;

		public override void OnEnter() {
			#if UNITY_EDITOR
				Fsm.Event(successEvent);
				Finish();
			#endif

	   		#if !UNITY_EDITOR
				InitAndroidInventoryTask iTask = InitAndroidInventoryTask.Create();
				iTask.ActionComplete += OnInvComplete;
				iTask.ActionFailed += OnInvFailed;
				iTask.Run();
			#endif			
		}

		private void OnInvComplete() {
			if(AndroidInAppPurchaseManager.instance.inventory.GetProductDetails(ProductSKU.Value) != null) {
				OnSuccess();
			} else {
				OnFailed();
			}
		}

		private void OnInvFailed() {
			OnFailed();
		}

		private void OnSuccess() {
			GoogleProductTemplate tpl =  AndroidInAppPurchaseManager.instance.inventory.GetProductDetails(ProductSKU.Value);

			price.Value = tpl.price;
			title.Value = tpl.title;
			description.Value = tpl.description;
			priceAmountMicros.Value = (int)tpl.priceAmountMicros;
			priceCurrencyCode.Value = tpl.priceCurrencyCode;

			Fsm.Event(successEvent);
			Finish();
		}

		private void OnFailed() {
			Fsm.Event(failEvent);
			Finish();
		}
	}
}
