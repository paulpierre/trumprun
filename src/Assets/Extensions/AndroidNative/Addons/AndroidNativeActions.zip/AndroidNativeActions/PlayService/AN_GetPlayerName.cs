﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("Android Native - PlayService")]
	public class AN_GetPlayerName : FsmStateAction {

		public FsmEvent Success;
		public FsmEvent Fail;

		public FsmString Name;

		public override void OnEnter() {
			if (GooglePlayManager.Instance.player != null) {
				Name.Value = GooglePlayManager.Instance.player.name;

				Fsm.Event(Success);
				Finish();
			} else {
				Fsm.Event(Fail);
				Finish();
			}
		}
	}

}
