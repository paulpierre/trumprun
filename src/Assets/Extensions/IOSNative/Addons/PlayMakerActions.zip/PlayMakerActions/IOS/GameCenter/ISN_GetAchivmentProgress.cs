﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Game Cneter")]
	public class ISN_GetAchivmentProgress : FsmStateAction {


		public FsmString achievementId;
		public FsmFloat achievementProgress;

		
		public override void Reset() {
			
		}


		public override void OnEnter() {

			if(GameCenterManager.IsAchievementsInfoLoaded) {
				Debug.Log("ISN_GetAchivmentProgress: Progress Already Loaded");
				achievementProgress.Value = GameCenterManager.GetAchievementProgress(achievementId.Value);
				Finish();
			} else {

				Debug.Log("ISN_GetAchivmentProgress: Waiting for Load Event");
				GameCenterManager.OnAchievementsLoaded += OnAchievementsLoaded;
				GameCenterManager.OnAchievementsLoaded += OnAchievementsLoaded;
			}



			
		}


		//--------------------------------------
		//  EVENTS
		//--------------------------------------



		private void OnAchievementsLoaded (ISN_Result res) {
			if(res.IsSucceeded) {
				Debug.Log("ISN_GetAchivmentProgress: Progress Loaded");
				achievementProgress.Value = GameCenterManager.GetAchievementProgress(achievementId.Value);

			} else {
				Debug.Log("ISN_GetAchivmentProgress: Load event failed");
				achievementProgress.Value = 0;
			}

			Finish();
		}
	}
}

